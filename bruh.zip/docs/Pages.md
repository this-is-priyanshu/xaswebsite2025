# Main Pages

LANDING PAGE + MAIN PAGE 
-About Us
-menu
-gallery
-important events

MENU
Events
About us (team)
Reseach + student research
Resources/Internships
Astroblogs
FELO

## Landing

Main Sections, fill with lorem ipsum as nessesary

0. Hamburger menu
1. Big XAS logo and Text with moto 
2. About XAS
3. Gallery 
4. Rescent Events list
5. Contact Us

## About Us

Content Same as people.html page

## Events + Astrovaganza

Content Same as the event page and astrovaganza pdf

## Research

Major Sections:

1. Department research
2. Student Research

Content For now same as research page

## Resources

Requires major redesign any new ideas are welcome, the content
is in the pdf.


