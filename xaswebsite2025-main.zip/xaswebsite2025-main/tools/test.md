# Hello This is a heading

## H3ll0 #

This is a small paragraph

This is another paragraph

- This is a list in another paragraph
- This is the continuation of the previous list
    - This is a list within the list
    - This is another list within the list
- This is continuation of the list

Ok cool eyyy, now we move on

1. This is a ordered list
2. This is another ordered list
    3. This is something cool idk
    4. Hahahah
6. The numeric value does not matter just that it is a numeric value


Possible list values  - for unordered 1. for ordered list

two spaces at the end of line indicates a linebreak  

Emphatic letters are written like this
*This is italic* **This is bold** ***This is bold italic***

Links: [This is somethig](asldkfjasdlfkj)
Image: ![This is somethig](asldkfjasdlfkj)
